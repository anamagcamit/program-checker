package sample;

import static junit.framework.TestCase.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import javafx.scene.control.TextField;
import org.junit.jupiter.api.Test;

import java.io.IOException;


public class Tests {

    @Test
    void GetFilesTest() {
        Controller cont = new Controller();
        cont.FolderDirectories();
        assertTrue(cont.foldercounter!=0);
    }

    @Test
    void GetFilesInFolder() throws IOException{
        Controller cont = new Controller();
        cont.GetFilesPerFolder();
        assertTrue(cont.folderdirectories.length!=0);
    }


    @Test
    void GetDirectoryTest(){
        Controller cont = new Controller();
        cont.GetDirectory();
        assertTrue(cont.directoryfromuser!=null);

    }

}
