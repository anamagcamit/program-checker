package sample;
//C:\\Users\\hp\\Desktop\\Test
import java.awt.*;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import java.util.stream.Collectors;
import java.util.stream.Stream;


import javafx.event.ActionEvent;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.swing.text.html.ImageView;

public class Controller {

    public TextArea huhu;
    public TextArea textArea1;
    public TextArea textArea2;
    public GridPane griding;
    public AnchorPane MainPane;
    public Button button2;

    public TextField directoryfromuser;                         //this will take in the directory the user will input


    public GridPane metricsgrid;

    private Label[] label3 = new Label[20];
    private Label[] label4 = new Label[40];
    private Label[] label5 = new Label[40];
    private Label[] label6 = new Label[40];
    private Label[] label7 = new Label[40];
    private Label[] label8 = new Label[40];
    private Label[] label9 = new Label[40];
    private Label[][] label = new Label[20][20];
    private Label[] label2 = new Label[20];

    String[] folderdirectories = new String[2000];               //this array will take the folder names and get their directory
    Queue<String> filenamesforlabels = new LinkedList<>();

   // File dir = new File(String.valueOf(directoryfromuser));              //this is the directory of the main folder
   // File[] files = dir.listFiles((d, name) -> name.endsWith(".txt"));   ///this takes in the txt files in the main folder

    File dir;
    //File[] files = new File[100];
    final myNumber myNum = new myNumber();

    int totalfilecounter;            //this will count the number of files
    int totalcompfiles;
    double progress = 0;
    int foldercounter = 0;

    float[][] matrix= new float[100][100];          //this takes in the matrix results

    String directoryforprogram = "";
    String printing = "";
    String printFile1 = "";
    String printFile2 = "";
    String printColumn = "";
    String printMetrics = "";



    public void FolderDirectories(){

        try (Stream<Path> walk = Files.walk(Paths.get(directoryforprogram))) { //"C:\\Users\\hp\\Desktop\\huhu"
            List<String> result = walk.filter(Files::isDirectory).map(x -> x.toString()).collect(Collectors.toList());

            foldercounter = result.size();
            //System.out.println(foldercounter);
            System.out.println(foldercounter);
            for(int i=0;i<foldercounter;i++){
                folderdirectories[i] = result.get(i);
                System.out.println(folderdirectories[i]);
            }

        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }


    public void GetFilesPerFolder() throws IOException {
        for(int i=1;i<foldercounter;i++){
            int totalfilesinfolder = 0;
            File dir = new File(folderdirectories[i]);
            String[] filesinsidefodler = dir.list();                    //this simply says the name of the file
            String[] filesinsidefolderdir = new String[100];           //this stores the directory of the named file

            if(filesinsidefodler.length == 0){
                System.out.println("The directory is empty");
            }
            else{
                for(String aFile: filesinsidefodler){
                    String finname = folderdirectories[i]+"\\"+ aFile;   //this gives the directory plus the name of the file
                    filesinsidefolderdir[totalfilesinfolder]=finname;
                    totalfilesinfolder++;

                }
            }

            //System.out.println("88888888888888888888888888888888888888888");
            /*
            for(int j=0;j<totalfilesinfolder;j++){
                System.out.println(filesinsidefolderdir[j]);
            }*/

            PrintWriter pw = new PrintWriter(folderdirectories[i]+"_"+"output"+foldercounter+".txt");
            for(int j=0;j<totalfilesinfolder;j++){
                File currentfile = new File(filesinsidefolderdir[j]);
                BufferedReader br = new BufferedReader((new FileReader(currentfile)));
                String st =br.readLine();
                while(st != null){
                    pw.println(st);
                    st = br.readLine();
                }
                pw.flush();
                br.close();

            }
        }

    }


   static void RecursivePrint(File[] arr, int index,int level){
        //terminate condition
        if(index==arr.length) return;

        //tabs for internal levels
       for(int i = 0; i<level;i++){
           System.out.print("\t"); //basically tab to
       }

       //for files
       if(arr[index].isFile()){
           System.out.println(arr[index].getName());
       }

       //for sub-directories
       else if(arr[index].isDirectory()){
           System.out.println("["+arr[index].getName()+"]");

           //recursion for sub directories
           RecursivePrint(arr[index].listFiles(),0,level+1);
       }

       //recursion for main
       RecursivePrint(arr,++index,level);

   }


    public void Read(){
        for(int i = 1; i<foldercounter;i++){
            System.out.println(folderdirectories[i]);
        }
    }


    static void RecursiveStore(File[] arr, int index,int level,String path) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(path+" "+"output"+".txt",true));
        //terminate condition
        if(index==arr.length) {
            pw.close();
            return;}
        //tabs for internal level

        //for files
        if(arr[index].isFile()) {
            String checker = String.valueOf(arr[index]);
            //System.out.println(checker);
            //int isExists = checker.indexOf( "output.TXT");
            if(checker.indexOf("output.txt") > -1)
            {
                File chuchu = new File(String.valueOf(arr[index]));
                System.out.println(chuchu);
                if(chuchu.delete())                      //returns Boolean value
                {
                    System.out.println(chuchu.getName() + " deleted");   //getting and printing the file name
                }
            }

            else {
                File currentfile = new File(String.valueOf(arr[index]));
                BufferedReader br = new BufferedReader((new FileReader(currentfile)));
                String st = br.readLine();
                while (st != null) {
                    //System.out.println(st);
                    pw.println(st);
                    st = br.readLine();
                }
                br.close();
            }

            pw.flush();
            pw.close();


        }


        //for sub-directories
        else if(arr[index].isDirectory()){
            //System.out.println("["+arr[index].getName()+"]");
            //recursion for sub directories
            pw.close();
            RecursiveStore(arr[index].listFiles(),0,level+1,path);
        }

        pw.close();
        //recursion for main
        RecursiveStore(arr,++index,level,path);
        ;
    }

    public void SuperReaderCombine() throws IOException {
        for(int i=1;i<foldercounter;i++){
            String folderpath = folderdirectories[i];
            File folderfiles = new File(folderpath);

            if(folderfiles.exists()&&folderfiles.isDirectory()){
                File arr[] = folderfiles.listFiles();
                RecursiveStore(arr,0,0,folderdirectories[i]);
            }

        }

    }

    public void TxtDeleter(){
        File dir1 = new File(directoryforprogram); //"C:\\Users\\hp\\Desktop\\huhu"
        File[] files1 = dir1.listFiles((d, name) -> name.endsWith("output.txt"));


        totalfilecounter = files1.length;

        try{
            //System.out.println(totalfilecounter);

            for(int i=0;i<totalfilecounter;i++){
                //files[i] = result.get(i);
                //System.out.println("*************************************************");
                System.out.println(files1[i]);
                if(files1[i].delete())                      //returns Boolean value
                {
                    System.out.println(files1[i].getName() + " deleted");   //getting and printing the file name
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public void GetDirectory(){
        directoryforprogram =  directoryfromuser.getText();
    }


    public void GetFilesMainFolder(){
        try (Stream<Path> walk = Files.walk(Paths.get(directoryforprogram))) {

            List<String> result = walk.map(x -> x.toString())
                    .filter(f -> f.endsWith(".txt")).collect(Collectors.toList());

            //result.forEach(System.out::println);
            totalcompfiles = result.size();
            for(int i = 0;i<totalcompfiles;i++){
                filenamesforlabels.add(String.valueOf(result.get(i)));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void GetMainFilesForlabels(){
        File dir = new File(directoryforprogram);                               //file io
        String[] files = dir.list();
        //this function basically takes in the files and places it inside an array.
        if (files.length == 0) {
            System.out.println("The directory is empty");
        } else {
            for (String aFile : files) {
                filenamesforlabels.add(String.valueOf(aFile));
            }
        }
    }



    public void ReadFile() throws IOException {
        File dir3 = new File(String.valueOf(directoryforprogram));              //this is the directory of the main folder
        File[] compfiles = dir3.listFiles((d, name) -> name.endsWith(".txt"));   ///this takes in the txt files in the main folder

        totalcompfiles = compfiles.length;

        for(int i = 0;i<totalcompfiles;i++){
            filenamesforlabels.add(String.valueOf(compfiles[i]));
            for(int j=0;j<totalcompfiles;j++){
                String[] line1= new String[10000000];           //this stores the contents(by line of the first file) in an array for comparison
                String[] line2 = new String[10000000];          //this stores the contents (by line of the second file) in an array for comparison
                int a=0;
                int b=0;

                File currentfile1 = new File(String.valueOf(compfiles[i]));
                BufferedReader br1 = new BufferedReader((new FileReader(currentfile1)));
                String st1;
                while((st1 = br1.readLine()) != null){                                      //this stores the string in the array until the end of the file.
                    boolean isComment = false;
                    if (st1.trim().isEmpty()) {                                               // so that when it encounters an enter, it will not be stored in the array
                        continue;                                                            // this will skip white spaces
                    } else {
                        if(st1.trim().contains("/")){
                            if(st1.indexOf("/")==1){
                                isComment = true;
                            }
                            else{
                                st1 = st1.substring(0, st1.indexOf("/"));                   // if there is a comment after a text like this, it will only return the text without the comment
                            }
                        }
                        if (!isComment) {
                            line1[a] = st1;
                            //System.out.println(line1[a]);
                            a++;
                        }
                    }


                }
                //System.out.println(files[j]);
                File currentfile2 = new File(String.valueOf(compfiles[j]));
                BufferedReader br2 = new BufferedReader((new FileReader(currentfile2)));
                String st2;

                while((st2 = br2.readLine()) !=null){
                    boolean isComment2 = false;
                    if (st2.trim().isEmpty()) {
                        continue;
                    } else {
                        if(st2.trim().contains("/")){
                            if(st2.indexOf("/")==1){
                                isComment2 = true;
                            }
                            else{
                                st2 = st2.substring(0, st2.indexOf("/"));
                            }
                        }
                        if (!isComment2) {
                            line2[b] = st2;
                            //System.out.println(line2[b]);
                            b++;
                        }
                    }
                }

                br1.close();
                br2.close();


                int k = 0;                                                              //a -> k. this is the counter for each line for file 1
                int l = 0;                                                              //b -> l. this is the counter for each line for file 2
                float totallines = a+b;
                float checker=0;
                float different = 0;
                float percent = 0;
                int diffchecker = 0;

                if(a>b){                                    //this is when file1 has more lines than file2
                    for(int counter=0;counter<a;counter++){
                        for(int counter2=0; counter2<b;counter2++){
                            if(line1[counter].equals(line2[counter2])){
                                checker++;
                                //break;
                            }

                        }
                        if(checker==0){
                            diffchecker++;
                        }
                        checker=0;
                    }
                    different = totallines - diffchecker;
                    percent = (different/totallines);
                    matrix[i][j] = percent;

                }

                else{
                    for(int counter = 0; counter<b;counter++){
                        for(int counter2=0;counter2<a;counter2++){
                            if(line2[counter].equals(line1[counter2])) {
                                checker++;
                                // break;
                            }

                        }
                        if(checker==0){
                            diffchecker++;
                        }
                        checker=0;
                    }
                    different = totallines - diffchecker;
                    percent=(different/totallines);
                    matrix[i][j] = percent;
                }


                String finalnumber = String.format("%.2f",matrix[i][j]);
                printing = printing + finalnumber + "  ";
                System.out.print(finalnumber+" ");


            }

            printing = printing + "\n\n";
            System.out.println("\n");

        }
    }


    public void Print(){
        textArea1.setText(printFile1);
        huhu.setText(printing);
    }



    public void gridprint(){
        VBox score;
        for(int j=0;j<1;j++){  //this prints horizontally for the labels of the first row.
            for(int i=0;i<totalcompfiles;i++){ //i is for the column and j is for the row here.
                String k = filenamesforlabels.peek();
                label[i][j] = new Label(k);
                griding.add(label[i][j],i+1,j);
                filenamesforlabels.add(k);
                filenamesforlabels.remove();
            }
        }

        for(int j = 0;j<totalcompfiles;j++){
            String k = filenamesforlabels.poll();
            label2[j] = new Label(k);
            griding.add(label2[j],0,j+1);
        }

        for(int i=0;i<totalcompfiles;i++){
            for(int j=0;j<totalcompfiles;j++) {

                if (matrix[i][j] == 1.00) {
                    String finalnumber = String.format("%.2f", matrix[i][j]);
                    label[i][j] = new Label(finalnumber);
                    Label label1 = label[i][j];
                    label1.setStyle("-fx-background-color: red");
                    griding.add(label1, j + 1, i + 1);
                }
                else if((1.00 > matrix[i][j]) && (matrix[i][j]>0.80)){
                    String finalnumber = String.format("%.2f", matrix[i][j]);
                    label[i][j] = new Label(finalnumber);
                    Label label1 = label[i][j];
                    label1.setStyle("-fx-background-color: #FA6464");
                    griding.add(label1, j + 1, i + 1);
                }
                else if((0.80 > matrix[i][j]) && (matrix[i][j]>0.60)){
                    String finalnumber = String.format("%.2f", matrix[i][j]);
                    label[i][j] = new Label(finalnumber);
                    Label label1 = label[i][j];
                    label1.setStyle("-fx-background-color: orange");
                    griding.add(label1, j + 1, i + 1);
                }
                else if((0.60 > matrix[i][j]) && (matrix[i][j]>0.40)){
                    String finalnumber = String.format("%.2f", matrix[i][j]);
                    label[i][j] = new Label(finalnumber);
                    Label label1 = label[i][j];
                    label1.setStyle("-fx-background-color: yellow");
                    griding.add(label1, j + 1, i + 1);
                }

                else if((0.40 > matrix[i][j])&& (matrix[i][j]>0.20)){
                    String finalnumber = String.format("%.2f", matrix[i][j]);
                    label[i][j] = new Label(finalnumber);
                    Label label1 = label[i][j];
                    label1.setStyle("-fx-background-color: #59FF00");
                    griding.add(label1, j + 1, i + 1);
                }

                else {
                   // String finalnumber = String.format("%.2f", matrix[i][j]);
                    //label[i][j] = new Label(finalnumber);
                   // griding.add(label[i][j], j + 1, i + 1);
                    //griding.setStyle("-fx-background-color: #C0C0C0;");
                    String finalnumber = String.format("%.2f", matrix[i][j]);
                    label[i][j] = new Label(finalnumber);
                    Label label1 = label[i][j];
                    label1.setStyle("-fx-background-color: green");
                    griding.add(label1, j + 1, i + 1);
                }
            }
        }
    }


    public void Read2() throws IOException {
        GetDirectory();
        TxtDeleter();
        FolderDirectories();
        SuperReaderCombine();
        ReadFile();
        //GetMainFilesForlabels();
        gridprint();
        button2.setVisible(true);

        //C:\\Users\\hp\\Desktop\\Test
    }

    public void showMetrics(){
        label3[1] = new Label("Volume");
        label3[2] = new Label("Length");
        label3[3] = new Label("Difficulty");
        label3[4] = new Label("Effort");
        label3[5] = new Label("Time");

        for(int j = 1;j<6;j++){
            metricsgrid.add(label3[j],j,0);
        }
    }

    public void SystemMetrics(ActionEvent event) throws IOException{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("sample2.fxml"));
        Parent root = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
        directoryfromuser.setText(directoryforprogram);
    }

    public void PrintMetrics(ActionEvent event) throws IOException{
        GetDirectory();
        Metrics.ShowMetrics(directoryforprogram);
        showMetrics();
        int total = Metrics.getTotalFiles();
        for(int i=0;i<total;i++) {
            label4[i] = new Label(Metrics.getVol(i));
            label5[i] = new Label(Metrics.getLev(i));
            label6[i] = new Label(Metrics.getDif(i));
            label7[i] = new Label(Metrics.getEff(i));
            label8[i] = new Label(Metrics.getTime(i));
            metricsgrid.add(label4[i], 1, i+1);
            metricsgrid.add(label5[i], 2, i+1);
            metricsgrid.add(label6[i], 3, i+1);
            metricsgrid.add(label7[i], 4, i+1);
            metricsgrid.add(label8[i], 5, i+1);
        }
        for(int i=0;i<total;i++) {
            label9[i] = new Label(Metrics.getFiles(i));
            metricsgrid.add(label9[i], 0,  i+1);
        }
    }

    public void Back(ActionEvent event) throws IOException{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("sample2.fxml"));
        Parent root = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }


}
