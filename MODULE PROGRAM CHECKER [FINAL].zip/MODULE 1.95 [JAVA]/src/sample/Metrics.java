package sample;

import javafx.scene.control.TextField;

import java.io.*;
import java.lang.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Metrics {

    static int vocab = 16;
    static String printing = "";
    static String printFile1 = "";

    static String directoryforprogram = "";
    static String[] finalVol = new String[100];
    static String[] finalLev = new String[100];
    static String[] finalDif = new String[100];
    static String[] finalEff = new String[100];
    static String[] finalTime = new String[100];
    static File[] compfiles = new File[100];

    static int[] operands = new int[100];
    static int[] operators = new int[100];

    static double n1 = 12, n2 = 4;

    static int progLength = 0;
    static double volume = 0;
    static double level = 0;
    static double difficulty = 0;
    static double effort = 0;
    static double time = 0;
    static double constant = 2/n1;

    static int totalfilecounter;            //this will count the number of files
    static int totalcompfiles;
    static int foldercounter = 0;

    static DecimalFormat met = new DecimalFormat("######.#####");

    public static void GetDirectory(String directory){
        directoryforprogram =  directory;
    }


    public static void ReadFiles() throws IOException {
        File dir3 = new File(String.valueOf(directoryforprogram));              //this is the directory of the main folder
        compfiles = dir3.listFiles((d, name) -> name.endsWith(".txt"));   ///this takes in the txt files in the main folder

        totalcompfiles = compfiles.length;

        for (int i = 0; i < totalcompfiles; i++) {
            File currentfile1 = new File(String.valueOf(compfiles[i]));
            BufferedReader br1 = new BufferedReader((new FileReader(currentfile1)));
            String st1;

            int period = 0, parenthesis = 0, brackets = 0, less = 0, semi = 0,
                    equals = 0, pluses = 0, squarebracks = 0, ifs = 0, fors = 0,
                    inum = 0, jnum = 0, xnum = 0, ynum = 0, intnum = 0, floatnum = 0;

            double logx=0;
            double constant2=0;

            while ((st1 = br1.readLine()) != null) {
                st1 = st1.replaceAll("\\s","");
                boolean isComment = false;
                if (st1.trim().isEmpty()) {                                               // so that when it encounters an enter, it will not be stored in the array
                    continue;                                                            // this will skip white spaces
                }
                else{
                    if(st1.trim().contains("/")){
                        if(st1.indexOf("/")==1){
                            isComment = true;
                        }
                        else{
                            st1 = st1.substring(0, st1.indexOf("/"));                   // if there is a comment after a text like this, it will only return the text without the comment
                        }
                    }
                    if (!isComment) {
                        for(int j = 0; j < st1.length(); j++){
                            if(st1.charAt(j)=='.') period++;
                            if(st1.charAt(j)=='(') parenthesis++;
                            if(st1.charAt(j)=='{') brackets++;
                            if(st1.charAt(j)=='<') less++;
                            if(st1.charAt(j)==';') semi++;
                            if(st1.charAt(j)=='=') equals++;
                            if(st1.charAt(j)=='+') pluses++;
                            if(st1.charAt(j)=='[') squarebracks++;
                            if(st1.charAt(j)=='i'){
                                if(j==st1.length()-1)  continue;
                                else if(st1.charAt(j+1)=='f') ifs++;
                                else if(st1.charAt(j+1)=='n'){
                                    if(j==st1.length()-2)  continue;
                                    else if(st1.charAt(j+2)=='t') intnum++;
                                    else continue;
                                }
                                else if(st1.charAt(j+1)=='='||st1.charAt(j+1)=='<'||st1.charAt(j+1)=='+') inum++;
                                else continue;
                            }
                            if(st1.charAt(j)=='f'){
                                if(j==st1.length()-1)  continue;
                                else if(st1.charAt(j+1)=='o'){
                                    if(j==st1.length()-2)  continue;
                                    else if(st1.charAt(j+2)=='r') fors++;
                                    else continue;
                                }
                                else if(st1.charAt(j+1)=='l'){
                                    if(j==st1.length()-2)  continue;
                                    else if (st1.charAt(j+2)=='o'){
                                        if(j==st1.length()-3)  continue;
                                        else if(st1.charAt(j+3)=='a'){
                                            if(j==st1.length()-4)  continue;
                                            else if (st1.charAt(j+4)=='t') floatnum++;
                                        }
                                    }
                                }
                                else continue;
                            }
                            if(st1.charAt(j)=='j'){
                                if(j==st1.length()-1) continue;
                                else{
                                    if(st1.charAt(j+1)=='=') jnum++;
                                    else if(st1.charAt(j+1)=='<') jnum++;
                                    else if(st1.charAt(j+1)=='+') jnum++;
                                }
                            }
                            if(st1.charAt(j)=='x'){
                                if(j==st1.length()-1) continue;
                                else {
                                    if(st1.charAt(j+1)=='=') xnum++;
                                    else if(st1.charAt(j+1)=='<') xnum++;
                                    else if(st1.charAt(j+1)=='+') xnum++;
                                }
                            }
                            if(st1.charAt(j)=='y'){
                                if(j==st1.length()-1) continue;
                                else{
                                    if(st1.charAt(j+1)=='=') ynum++;
                                    else if(st1.charAt(j+1)=='<') ynum++;
                                    else if(st1.charAt(j+1)=='+') ynum++;
                                }
                            }
                        }
                    }
                }
            }

            operators[i] = period + parenthesis + brackets + less + semi + equals + pluses + squarebracks + ifs + fors + intnum + floatnum;
            operands[i] = inum + jnum + ynum + xnum;

            progLength = operators[i] + operands[i];
            logx = Math.log(vocab)/Math.log(2);
            volume = progLength*logx;
            constant2 = (n2/operators[i]);
            level = constant*constant2;
            difficulty = (1/level);
            effort = (volume/level);
            time = (effort/18);
            finalVol[i] = met.format(volume);
            finalLev[i] = met.format(level);
            finalDif[i] = met.format(difficulty);
            finalEff[i] = met.format(effort);
            finalTime[i] = met.format(time);

        }
    }



    public static void ShowMetrics(String Directory) throws IOException{
        GetDirectory(Directory);
        ReadFiles();
    }

    public static String getVol(int i){
        return finalVol[i];
    }

    public static String getLev(int i){
        return finalLev[i];
    }

    public static String getDif(int i){
        return finalDif[i];
    }

    public static String getEff(int i){
        return finalEff[i];
    }

    public static String getTime(int i){
        return finalTime[i];
    }

    public static int getTotalFiles(){
        return totalcompfiles;
    }

    public static String getFiles(int i){
        return String.valueOf(compfiles[i]);
    }

}
